//Substitui o uso de "document.getElementById('id')".
function getE(id) {
  return document.getElementById(id); //Retorna o elemento.
}

//Substitui o uso de "document.getElementById('id').innerHTML = conteudo".
function inner(id, conteudo) { //Recebe o id do elemento e o conteúdo a ser colocado no elemento.
  document.getElementById(id).innerHTML = conteudo; //Substitui o conteúdo do elemento obtido por ID pelo conteúdo passao na função.
}

//Substitui o uso da função nativa de navegação do JavaScript: "location.replace('endereco')".
function nav(endereco, novaGuia = false) { //Recebe o nome da página para onde será feita a navegação e se será aberto em nova guia (padrão é não)
  if (novaGuia == false) { //Usará a função "location" para abrir na mesma página.
    window.location.replace("./" + endereco + ".html"); //Navega para outro endereço do projeto.
  } else { //Usará a função "open" para abrir uma nova janela.
    window.open(endereco, "_blank"); //Abre uma nova guia com o link do download.
  }
}

//Monta a string que será o link para download da versão escolhida do programa.
function download() {
  var versao = getE("downloadVersao").value; //Obtem o valor do select "downloadVersao".
  var sistema = getE("downloadSistema").value; //Obtem o valor do select "downloadSistema".
  var link = "http://downloads.mariadb.com/MariaDB/"; //Cria variável que conterá o link do download.

  if (versao == "") { //Verifica se a versão foi escolhida.
    alert("Selecione uma versão do MariaDB!"); //Se nao foi, exibe erro...
    return; //...e encerra a função.
  }

  if (versao == "") { //Verifica se os sistema operacional foi escolhido.
    alert("Selecione um sistema operacional!"); //Se nao foi, exibe erro...
    return; //...e encerra a função.
  }

  if (versao == "5.5.60") { //Verifica a versão escolhida.
    if (sistema == "ubuntu") { //Verifica o sistema operacional escolhido.
      link += "mariadb-10.3.6/winx64-packages/mariadb-10.3.6-winx64.msi"; //Concatena o link correto de download, de acordo com a versão e sistema escolhido.
    } else { //Caso o sistema não for compatível.
      alert("MariaDB não está disponível nesta versão para o sistema escolhido!"); //Exibe erro se não existir versão compatível.
    }
  } else if (versao == "10.3.6") { //Verifica a versão escolhida.
    if (sistema == "ubuntu") { //Verifica o sistema operacional escolhido.
      link += "mariadb-10.3.6/repo/ubuntu/mariadb-10.3.6-ubuntu-xenial-amd64-debs.tar"; //Concatena o link correto de download, de acordo com a versão e sistema escolhido.
    } else if (sistema == "windows") { //Verifica o sistema operacional escolhido.
      link += "mariadb-10.3.6/repo/ubuntu/mariadb-10.3.6-ubuntu-xenial-amd64-debs.tar"; //Concatena o link correto de download, de acordo com a versão e sistema escolhido.
    } else { //Caso o sistema não for compatível.
      alert("MariaDB não está disponível nesta versão para o sistema escolhido!"); //Exibe erro se não existir versão compatível.
    }
  } else if (versao == "10.2.14") { //Verifica a versão escolhida.
    if (sistema == "ubuntu") { //Verifica o sistema operacional escolhido.
      link += "mariadb-10.2.14/repo/ubuntu/mariadb-10.2.14-ubuntu-xenial-amd64-debs.tar"; //Concatena o link correto de download, de acordo com a versão e sistema escolhido.
    } else if (sistema == "windows") { //Verifica o sistema operacional escolhido.
      link += "mariadb-10.2.14/winx64-packages/mariadb-10.2.14-winx64.msi"; //Concatena o link correto de download, de acordo com a versão e sistema escolhido.
    } else if (sistema == "macos") { //Verifica o sistema operacional escolhido.
      link += "mariadb-10.2.14/macOS/mariadb-10.2.12-osx10.13-x86_64.pkg"; //Concatena o link correto de download, de acordo com a versão e sistema escolhido.
    } else { //Caso o sistema não for compatível.
      alert("MariaDB não está disponível nesta versão para o sistema escolhido!"); //Exibe erro se não existir versão compatível.
    }
  } else if (versao == "10.1.32") { //Verifica a versão escolhida.
    if (sistema == "ubuntu") { //Verifica o sistema operacional escolhido.
      link += "mariadb-10.1.32/repo/ubuntu/mariadb-10.1.32-ubuntu-xenial-amd64-debs.tar"; //Concatena o link correto de download, de acordo com a versão e sistema escolhido.
    } else if (sistema == "windows") { //Verifica o sistema operacional escolhido.
      link += "mariadb-10.1.32/winx64-packages/mariadb-10.1.32-winx64.msi"; //Concatena o link correto de download, de acordo com a versão e sistema escolhido.
    } else if (sistema == "macos") { //Verifica o sistema operacional escolhido.
      link += "mariadb-10.1.32/macOS/mariadb-10.1.32-osx10.12-x86_64.pkg"; //Concatena o link correto de download, de acordo com a versão e sistema escolhido.
    } else { //Caso o sistema não for compatível.
      alert("MariaDB não está disponível nesta versão para o sistema escolhido!"); //Exibe erro se não existir versão compatível.
    }
  } else { //Sobra apenas a versão 10.0.35
    if (sistema == "windows") { //Verifica o sistema operacional escolhido.
      link += "mariadb-10.0.35/winx64-packages/mariadb-10.0.35-winx64.msi"; //Concatena o link correto de download, de acordo com a versão e sistema escolhido.
    } else if (sistema == "ubuntu") { //Verifica o sistema operacional escolhido.
      link += "mariadb-10.0.35/repo/ubuntu/mariadb-10.0.35-ubuntu-xenial-amd64-debs.tar"; //Concatena o link correto de download, de acordo com a versão e sistema escolhido.
    } else { //Caso o sistema não for compatível.
      alert("MariaDB não está disponível nesta versão para o sistema escolhido!"); //Exibe erro se não existir versão compatível.
    }
  }

  nav(link, true); //Chama a função que irá abrir uma nova guia com o link de download

}
